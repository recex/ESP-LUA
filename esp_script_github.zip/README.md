# 🚀 Professional ESP Script for Roblox

Um script de ESP (Extra Sensory Perception) modular, organizado e otimizado para executores mobile e PC (como Delta, Fluxus, etc).

## 📂 Estrutura do Projeto

- `main.lua`: O carregador principal do script.
- `src/modules/`: Contém as funcionalidades específicas (Players, Items, etc).
- `src/utils/`: Funções utilitárias e bibliotecas de desenho.

## 🛠️ Como Usar

Para executar no seu executor favorito (Delta, etc), use o seguinte loadstring:

```lua
loadstring(game:HttpGet("https://raw.githubusercontent.com/SEU_USUARIO/SEU_REPO/main/main.lua"))()
```

> **Nota:** Lembre-se de substituir `SEU_USUARIO` e `SEU_REPO` pelo seu nome de usuário e nome do repositório no GitHub após fazer o upload.

## ✨ Funcionalidades

- [x] Box ESP (Jogadores)
- [x] Item ESP (Nomes)
- [x] NPC ESP (Box e Nomes)
- [x] Name ESP (Jogadores)
- [x] Sistema Modular (Fácil de expandir)
- [x] Otimizado para Delta Executor

## 📜 Licença

Este projeto está sob a licença MIT.
